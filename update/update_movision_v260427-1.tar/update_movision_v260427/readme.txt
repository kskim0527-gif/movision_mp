모델명 : MOVISION-MOVISION
F/W : 260427
날짜 : 2026-04-27 17:18:14

[Flash Addresses]
bootloader.bin	0x0
partition-table.bin	0x8000
ota_data_initial.bin	0xF000
movision.bin (Main)	0x20000
storage.bin	0x3b2000
